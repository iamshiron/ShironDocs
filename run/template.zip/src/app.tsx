import { useState } from "preact/hooks";
import { Router, type RouterOnChangeArgs } from "preact-router";

import { ThemeProvider } from "./contexts/ThemeContext";
import { Layout } from "./layouts/Layout";
import { PAGES } from "./utils/pages";

export function App() {
	const [url, setUrl] = useState(
		typeof window !== "undefined" ? window.location.pathname : "/",
	);

	const handleRoute = (e: RouterOnChangeArgs) => {
		setUrl(e.url);
		if (typeof window !== "undefined") {
			if (!window.location.hash) {
				window.scrollTo(0, 0);
			}
		}
	};

	return (
		<ThemeProvider>
			<Layout currentPath={url}>
				<Router onChange={handleRoute}>
					{PAGES.map((page) => (
						<page.Content key={page.id} path={page.path} />
					))}
				</Router>
			</Layout>
		</ThemeProvider>
	);
}
