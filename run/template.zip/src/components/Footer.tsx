import { IconMap } from "../utils/icons";
import { CONFIG } from "../config";

const { Moon } = IconMap;
const BrandIcon = IconMap[CONFIG.branding.logoIcon];

export function Footer() {
	return (
		<footer class="mt-3 pt-3 pb-3 border-t border-glass-border text-text-muted text-xs">
			<div class="flex flex-col sm:flex-row justify-between items-center gap-6 flex-wrap">
				<div class="flex flex-col gap-2">
					<div class="font-semibold text-text-main flex items-center gap-2 text-base">
						<BrandIcon size={18} weight="fill" class="text-accent-primary" />
						<span>{CONFIG.branding.libraryName}</span>
					</div>
					<p class="m-0 opacity-70 max-w-md leading-relaxed">
						{CONFIG.branding.tagline} • {CONFIG.branding.copyright}
					</p>
				</div>
				<div class="flex gap-6">
					{CONFIG.navigation.footerLinks.map((link) => (
						<a
							href={link.href}
							class="text-text-muted transition-colors duration-200 cursor-pointer no-underline hover:text-accent-primary hover:underline"
						>
							{link.label}
						</a>
					))}
				</div>
			</div>
		</footer>
	);
}
