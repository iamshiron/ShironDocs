import { Link } from "preact-router";
import { useTheme } from "../contexts/ThemeContext";
import { IconMap } from "../utils/icons";
import { CONFIG } from "../config";

const { List, MagnifyingGlass, Sun, Moon, GithubLogo } = IconMap;
const BrandIcon = IconMap[CONFIG.branding.logoIcon];

interface HeaderProps {
	onMenuClick: () => void;
	onSearchClick: () => void;
	currentPath: string;
}

export function Header({
	onMenuClick,
	onSearchClick,
	currentPath,
}: HeaderProps) {
	const { toggleTheme, theme } = useTheme();

	const isGuides =
		currentPath === "/" ||
		(currentPath.startsWith("/guides/") &&
			!currentPath.startsWith("/api") &&
			!currentPath.startsWith("/mcp"));
	const isApi = currentPath.startsWith("/api");
	const isMcp = currentPath.startsWith("/mcp");

	return (
		<header class="fixed top-0 left-0 right-0 h-header-height bg-header-bg backdrop-blur-xl border-b border-glass-border flex items-center justify-between px-4 z-[1000] transition-[background] duration-300">
			<div class="flex items-center gap-2">
				<button
					class="md:hidden bg-transparent border-none text-text-muted cursor-pointer p-2 transition-colors duration-200 hover:text-text-main flex items-center"
					onClick={onMenuClick}
				>
					<List size={24} />
				</button>

				<div class="flex items-center gap-2 font-bold text-xl text-accent-primary [text-shadow:0_0_20px_var(--accent-glow)]">
					<BrandIcon size={22} weight="fill" />
					<span>{CONFIG.branding.appTitle}</span>
				</div>
			</div>

			<nav class="hidden md:flex gap-6 h-full items-center mx-4">
				<Link
					href="/"
					class={`flex items-center h-full text-sm border-b-2 cursor-pointer transition-colors duration-200 ${
						isGuides
							? "text-accent-primary border-accent-primary"
							: "text-text-muted border-transparent hover:text-text-main"
					}`}
				>
					Home
				</Link>
			</nav>

			<div class="flex gap-2 items-center">
				<div
					class="flex items-center gap-2 bg-glass-surface border border-glass-border py-1.5 px-2.5 rounded-md text-text-muted cursor-pointer transition-colors duration-200 min-w-0 sm:min-w-[200px] hover:border-accent-primary hover:text-text-main hover:bg-white/5 data-[theme=light]:hover:bg-black/5"
					onClick={onSearchClick}
				>
					<MagnifyingGlass size={16} />
					<span class="text-[0.85rem] hidden sm:inline">Search...</span>
					<span class="text-[0.7rem] bg-glass-border px-1.5 py-0.5 rounded-sm font-mono ml-auto border border-transparent hidden md:inline">
						Ctrl + /
					</span>
				</div>

				<div
					class="w-9 h-9 text-text-muted cursor-pointer transition-all duration-200 flex items-center justify-center hover:text-text-main hover:scale-110"
					onClick={toggleTheme}
				>
					{theme === "light" ? <Moon size={18} /> : <Sun size={18} />}
				</div>

				<div
					class="w-9 h-9 text-text-muted cursor-pointer transition-all duration-200 flex items-center justify-center hover:text-text-main hover:scale-110"
					onClick={() =>
						window.open(CONFIG.navigation.externalLinks.github, "_blank")
					}
				>
					<GithubLogo size={18} />
				</div>
			</div>
		</header>
	);
}
