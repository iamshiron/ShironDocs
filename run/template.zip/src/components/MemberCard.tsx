import { useState } from "preact/hooks";
import { IconMap } from "../utils/icons";

const { CaretDown } = IconMap;

interface MemberCardProps {
	id?: string;
	name?: string;
	signature: string;
	description: string;
	params?: { name: string; type: string; desc: string }[];
	initialOpen?: boolean;
}

export function MemberCard({
	id,
	name,
	signature,
	description,
	params,
	initialOpen = false,
}: MemberCardProps) {
	const [open, setOpen] = useState(initialOpen);
	return (
		<div class="bg-white/[0.02] data-[theme=light]:bg-black/[0.02] border border-glass-border rounded-md mb-3 transition-colors duration-200 hover:bg-white/[0.04] data-[theme=light]:hover:bg-black/[0.04] hover:border-glass-highlight">
			<div
				class="p-2.5 sm:p-3 flex justify-between items-center"
				onClick={() => params && setOpen(!open)}
				style={{ cursor: params ? "pointer" : "default" }}
			>
				<h4
					class="font-mono text-[0.9rem] text-text-code m-0 font-inherit leading-inherit"
					id={id}
					data-toc-label={name}
					dangerouslySetInnerHTML={{ __html: signature }}
				/>
				{params && (
					<CaretDown
						size={16}
						class={`transition-transform duration-200 ${open ? "rotate-180" : "rotate-0"}`}
					/>
				)}
			</div>
			<div
				class={`p-3 border-t border-glass-border ${open || !params ? "block animate-fade-in" : "hidden"}`}
			>
				<p class="mb-2.5 text-text-main">{description}</p>
				{params && (
					<table class="api-table">
						<thead>
							<tr>
								<th>Name</th>
								<th>Type</th>
								<th>Description</th>
							</tr>
						</thead>
						<tbody>
							{params.map((p) => (
								<tr>
									<td class="font-mono font-semibold text-text-main">
										{p.name}
									</td>
									<td>
										<span class="text-sh-type font-mono font-medium cursor-pointer hover:underline">
											{p.type}
										</span>
									</td>
									<td>{p.desc}</td>
								</tr>
							))}
						</tbody>
					</table>
				)}
			</div>
		</div>
	);
}
