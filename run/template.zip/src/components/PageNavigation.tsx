import { Link, route } from "preact-router";
import { PAGES } from "../utils/pages";
import { IconMap } from "../utils/icons";
import { NavLink } from "./Sidebar";

const { CaretLeft, CaretRight } = IconMap;

interface PageNavigationProps {
	currentPath: string;
}

export function PageNavigation({ currentPath }: PageNavigationProps) {
	const currentIndex = PAGES.findIndex((p) => p.path === currentPath);
	if (currentIndex === -1) return null;

	const prev = currentIndex > 0 ? PAGES[currentIndex - 1] : null;
	const next = currentIndex < PAGES.length - 1 ? PAGES[currentIndex + 1] : null;

	console.log({ prev, next });

	return (
		<div class="flex gap-3 mt-3 pt-3 border-t border-glass-border flex-col sm:flex-row items-stretch">
			{prev ? (
				<NavLink
					href={prev.path}
					className="flex-1 w-full sm:w-1/2 flex flex-col p-4 rounded-lg border border-glass-border bg-white/[0.02] data-[theme=light]:bg-black/[0.02] no-underline transition-all duration-200 cursor-pointer min-w-0 text-left items-start hover:border-accent-primary hover:bg-white/[0.04] data-[theme=light]:hover:bg-black/[0.04] hover:-translate-y-0.5 group"
				>
					<span class="text-xs uppercase tracking-wider text-text-muted mb-2">
						Previous
					</span>
					<span class="text-lg font-semibold text-text-main flex items-center gap-2">
						<CaretLeft
							size={18}
							class="text-accent-primary transition-transform duration-200 group-hover:scale-120"
						/>
						<span>{prev.label}</span>
					</span>
				</NavLink>
			) : (
				<div class="flex-1 hidden sm:block pointer-events-none" />
			)}

			{next ? (
				<NavLink
					href={next.path}
					className="flex-1 w-full sm:w-1/2 flex flex-col p-4 rounded-lg border border-glass-border bg-white/[0.02] data-[theme=light]:bg-black/[0.02] no-underline transition-all duration-200 cursor-pointer min-w-0 text-right items-end hover:border-accent-primary hover:bg-white/[0.04] data-[theme=light]:hover:bg-black/[0.04] hover:-translate-y-0.5 group"
				>
					<span class="text-xs uppercase tracking-wider text-text-muted mb-2">
						Next
					</span>
					<span class="text-lg font-semibold text-text-main flex items-center gap-2">
						<span>{next.label}</span>
						<CaretRight
							size={18}
							class="text-accent-primary transition-transform duration-200 group-hover:scale-120"
						/>
					</span>
				</NavLink>
			) : (
				<div class="flex-1 hidden sm:block pointer-events-none" />
			)}
		</div>
	);
}
