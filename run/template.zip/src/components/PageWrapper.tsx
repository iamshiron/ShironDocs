import type { ComponentChildren } from "preact";

interface PageWrapperProps {
	children: ComponentChildren;
}

export const PageWrapper = ({ children }: PageWrapperProps) => (
	<div class="animate-fade-in">{children}</div>
);
