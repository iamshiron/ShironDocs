import { useEffect, useState } from "preact/hooks";

interface Heading {
	id: string;
	text: string;
	level: number;
	element: HTMLElement;
}

interface RightSidebarProps {
	currentPath: string;
}

const GROUP_WORDS = [
	"constructors",
	"properties",
	"methods",
	"fields",
	"events",
	"namespaces",
	"classes",
	"interfaces",
	"quick-reference",
	"information",
];

const isGroupLabel = (h: Heading) =>
	(h.level === 2 || h.level === 3) &&
	(GROUP_WORDS.includes(h.id.toLowerCase()) ||
		GROUP_WORDS.some((word) => h.text.toLowerCase().includes(word)));

export function RightSidebar({ currentPath }: RightSidebarProps) {
	const [headings, setHeadings] = useState<Heading[]>([]);
	const [activeId, setActiveId] = useState("");

	useEffect(() => {
		const handleHashScroll = () => {
			const hash = window.location.hash.slice(1);
			if (hash) {
				const el = document.getElementById(hash);
				if (el) {
					const offset = 100;
					const bodyRect = document.body.getBoundingClientRect().top;
					const elementRect = el.getBoundingClientRect().top;
					const elementPosition = elementRect - bodyRect;
					const offsetPosition = elementPosition - offset;
					window.scrollTo({ top: offsetPosition, behavior: "smooth" });
					setActiveId(hash);
				}
			}
		};

		const handleGlobalClick = (e: MouseEvent) => {
			const target = e.target as HTMLElement;
			const link = target.closest("a");
			if (
				link &&
				link.hash &&
				(link.pathname === window.location.pathname || link.pathname === "")
			) {
				const id = link.hash.slice(1);
				const el = document.getElementById(id);
				if (el) {
					e.preventDefault();
					scrollTo(id);
				}
			}
		};

		window.addEventListener("hashchange", handleHashScroll);
		window.addEventListener("popstate", handleHashScroll);
		window.addEventListener("click", handleGlobalClick);

		return () => {
			window.removeEventListener("hashchange", handleHashScroll);
			window.removeEventListener("popstate", handleHashScroll);
			window.removeEventListener("click", handleGlobalClick);
		};
	}, []);

	useEffect(() => {
		const timer = setTimeout(() => {
			const main = document.querySelector("main.content");
			if (!main) return;

			const headers = Array.from(
				main.querySelectorAll("h1, h2, h3, h4"),
			) as HTMLElement[];

			if (headers.length === 0) {
				setHeadings([]);
				return;
			}

			const items = headers.map((header) => {
				if (!header.id) {
					header.id = header.innerText
						.toLowerCase()
						.replace(/\s+/g, "-")
						.replace(/[^\w-]+/g, "");
				}
				let level = 1;
				if (header.tagName === "H1") level = 1;
				if (header.tagName === "H2") level = 2;
				if (header.tagName === "H3") level = 3;
				if (header.tagName === "H4") level = 4;

				const text = header.getAttribute("data-toc-label") || header.innerText;

				return {
					id: header.id,
					text: text,
					level: level,
					element: header,
				};
			});
			setHeadings(items);

			// Handle initial hash scroll
			const hash = window.location.hash.slice(1);
			if (hash) {
				const el = document.getElementById(hash);
				if (el) {
					const offset = 100;
					const bodyRect = document.body.getBoundingClientRect().top;
					const elementRect = el.getBoundingClientRect().top;
					const elementPosition = elementRect - bodyRect;
					const offsetPosition = elementPosition - offset;
					window.scrollTo({ top: offsetPosition, behavior: "smooth" });
					setActiveId(hash);
				}
			}
		}, 150);

		return () => clearTimeout(timer);
	}, [currentPath]);

	useEffect(() => {
		if (headings.length === 0) return;

		const onScroll = () => {
			const scrollPos = window.scrollY + 120;
			let current = "";

			// Special case: Top of page
			if (window.scrollY < 50) {
				const firstSelectable = headings.find(
					(h) => h.level > 1 && !isGroupLabel(h),
				);
				if (firstSelectable) {
					setActiveId(firstSelectable.id);
					return;
				}
			}

			for (let i = 0; i < headings.length; i++) {
				const h = headings[i];
				if (h.element.offsetTop <= scrollPos) {
					if (isGroupLabel(h) || h.level === 1) {
						// If it's a label or H1, try to pick the first selectable item after it
						const nextSelectable = headings
							.slice(i + 1)
							.find((next) => next.level > 1 && !isGroupLabel(next));

						// Only update if we found one, otherwise keep current (or H1 as fallback)
						if (nextSelectable) {
							current = nextSelectable.id;
						} else {
							current = h.id;
						}
					} else {
						current = h.id;
					}
				} else {
					break;
				}
			}

			if (current && current !== activeId) {
				setActiveId(current);
			}
		};

		window.addEventListener("scroll", onScroll, { passive: true });
		onScroll();

		return () => window.removeEventListener("scroll", onScroll);
	}, [headings, activeId]);

	const scrollTo = (id: string) => {
		const el = document.getElementById(id);
		if (el) {
			const offset = 100;
			const bodyRect = document.body.getBoundingClientRect().top;
			const elementRect = el.getBoundingClientRect().top;
			const elementPosition = elementRect - bodyRect;
			const offsetPosition = elementPosition - offset;

			window.scrollTo({ top: offsetPosition, behavior: "smooth" });

			// Update URL hash without reload
			if (window.location.hash !== `#${id}`) {
				history.pushState(null, "", `#${id}`);
			}
			setActiveId(id);
		}
	};

	return (
		<aside class="hidden xl:flex sticky top-header-height h-[calc(100vh-var(--spacing-header-height))] w-[18%] min-w-[240px] max-w-[300px] p-5 border-l border-glass-border bg-sidebar-bg overflow-y-auto flex-col text-[0.85rem]">
			<div class="font-semibold text-text-main mb-4 text-[0.8rem] uppercase tracking-wider">
				On This Page
			</div>
			<div class="flex flex-col gap-1">
				{headings.length === 0 ? (
					<span class="text-[0.8rem] text-text-muted italic">
						No subsections
					</span>
				) : (
					headings.map((h) => {
						if (h.level === 1) return null;

						if (isGroupLabel(h)) {
							return (
								<div
									key={h.id}
									class="mt-2 first:mt-0 mb-1 text-[0.7rem] font-bold text-text-muted uppercase tracking-widest select-none"
								>
									{h.text}
								</div>
							);
						}

						return (
							<div
								key={h.id}
								class={`pl-2.5 border-l-2 transition-colors duration-200 cursor-pointer ${
									h.level <= 2 ? "" : h.level === 3 ? "ml-2" : "ml-4"
								} ${
									activeId === h.id
										? "text-accent-primary border-accent-primary"
										: "text-text-muted border-glass-border hover:text-text-main hover:border-text-muted"
								}`}
								onClick={() => scrollTo(h.id)}
							>
								{h.text}
							</div>
						);
					})
				)}
			</div>
		</aside>
	);
}
