import { useState, useEffect, useRef } from "preact/hooks";
import { route } from "preact-router";
import { PAGES, type Page } from "../utils/pages";
import { IconMap } from "../utils/icons";

const { MagnifyingGlass, Hash } = IconMap;

interface SearchModalProps {
	isOpen: boolean;
	onClose: () => void;
}

export function SearchModal({ isOpen, onClose }: SearchModalProps) {
	const [query, setQuery] = useState("");
	const [results, setResults] = useState<Page[]>([]);
	const [selectedIndex, setSelectedIndex] = useState(0);
	const inputRef = useRef<HTMLInputElement>(null);

	useEffect(() => {
		if (isOpen) {
			setTimeout(() => inputRef.current?.focus(), 50);
			setQuery("");
			setResults([]);
		}
	}, [isOpen]);

	useEffect(() => {
		if (!query) {
			setResults([]);
			return;
		}
		const filtered = PAGES.filter(
			(p) =>
				p.label.toLowerCase().includes(query.toLowerCase()) ||
				p.id.toLowerCase().includes(query.toLowerCase()),
		);
		setResults(filtered);
		setSelectedIndex(0);
	}, [query]);

	const handleKeyDown = (e: KeyboardEvent) => {
		if (e.key === "Escape") onClose();
		if (e.key === "ArrowDown") {
			e.preventDefault();
			setSelectedIndex((prev) => Math.min(prev + 1, results.length - 1));
		}
		if (e.key === "ArrowUp") {
			e.preventDefault();
			setSelectedIndex((prev) => Math.max(prev - 1, 0));
		}
		if (e.key === "Enter") {
			if (results[selectedIndex]) {
				route(results[selectedIndex].path);
				onClose();
			}
		}
	};

	if (!isOpen) return null;

	return (
		<div
			id="search-modal"
			class="fixed inset-0 bg-black/60 backdrop-blur-sm z-[2000] flex items-start justify-center p-4 sm:p-10 pt-[15vh] transition-opacity duration-300 animate-fade-in"
			onClick={(e) =>
				(e.target as HTMLElement).id === "search-modal" && onClose()
			}
		>
			<div class="w-full max-w-[600px] bg-bg-main border border-glass-border rounded-lg shadow-2xl flex flex-col overflow-hidden">
				<div class="p-4 flex items-center gap-3 border-b border-glass-border">
					<MagnifyingGlass size={20} class="text-accent-primary" />
					<input
						type="text"
						ref={inputRef}
						class="flex-1 bg-transparent border-none text-text-bright outline-none text-lg placeholder:text-text-muted"
						placeholder="Search documentation..."
						autocomplete="off"
						value={query}
						onInput={(e) => setQuery((e.target as HTMLInputElement).value)}
						onKeyDown={handleKeyDown}
					/>
					<span class="text-[0.7rem] bg-glass-border px-1.5 py-0.5 rounded-sm text-text-muted font-mono">
						ESC
					</span>
				</div>
				<div class="max-h-[60vh] overflow-y-auto p-2">
					{results.map((item, index) => (
						<div
							key={item.id}
							class={`p-3 rounded-md flex flex-col gap-1 cursor-pointer transition-colors duration-200 ${
								index === selectedIndex
									? "bg-accent-primary/10 text-accent-primary"
									: "hover:bg-glass-surface text-text-main"
							}`}
							onClick={() => {
								route(item.path);
								onClose();
							}}
							onMouseEnter={() => setSelectedIndex(index)}
						>
							<div class="font-semibold">{item.label}</div>
							<div class="text-[0.8rem] flex items-center gap-2 opacity-70">
								<Hash size={12} /> {item.tab}
							</div>
						</div>
					))}
					{query && results.length === 0 && (
						<div class="p-4 text-text-muted text-center">No results found.</div>
					)}
				</div>

				<div class="p-3 border-t border-glass-border flex gap-4 text-[0.75rem] text-text-muted">
					<div class="flex items-center gap-1.5">
						<span class="bg-glass-border px-1 rounded-sm text-text-bright">
							↵
						</span>
						<span>to select</span>
					</div>
					<div class="flex items-center gap-1.5">
						<span class="bg-glass-border px-1 rounded-sm text-text-bright">
							↓
						</span>
						<span class="bg-glass-border px-1 rounded-sm text-text-bright">
							↑
						</span>
						<span>to navigate</span>
					</div>
					<div class="flex items-center gap-1.5 ml-auto">
						<span class="bg-glass-border px-1 rounded-sm text-text-bright">
							esc
						</span>
						<span>to close</span>
					</div>
				</div>
			</div>
		</div>
	);
}
