import { useState } from "preact/hooks";
import { Link, route } from "preact-router";
import type { ComponentChildren } from "preact";
import { PAGES, NAVIGATION, type NavItem } from "../utils/pages";
import { IconMap } from "../utils/icons";

const { BookOpen, Code, Cpu, CaretDown } = IconMap;

interface NavLinkProps {
	href: string;
	currentPath?: string;
	children: ComponentChildren;
	className?: string;
	onClick?: (e: MouseEvent) => void;
}

export const NavLink = ({
	href,
	currentPath,
	children,
	className,
	onClick,
}: NavLinkProps) => {
	const isActive = currentPath === href;
	const handleClick = (e: MouseEvent) => {
		if (onClick) onClick(e);
		if (e.defaultPrevented || e.button !== 0) return;
		e.preventDefault();
		route(href);
	};

	return (
		<Link
			path={href}
			class={`${className} ${isActive ? "text-accent-primary" : ""}`}
			onClick={handleClick}
		>
			{children}
		</Link>
	);
};

const NavTree = ({
	item,
	currentPath,
	onClick,
}: {
	item: NavItem;
	currentPath: string;
	onClick: () => void;
}) => {
	const [expanded, setExpanded] = useState(true);

	const Icon = item.icon ? IconMap[item.icon] : null;
	const page = item.id ? PAGES.find((p) => p.id === item.id) : null;

	// Leaf node (no sub-items, no explicit icon/label - just a link)
	if (page && !item.items && !item.icon && !item.label) {
		const isActive = currentPath === page.path;
		return (
			<NavLink
				href={page.path}
				currentPath={currentPath}
				className={`block px-2.5 py-0.5 text-[0.85rem] cursor-pointer no-underline transition-colors duration-200 hover:text-accent-primary ${isActive ? "" : "text-text-bright"}`}
				onClick={() => onClick()}
			>
				<page.title />
			</NavLink>
		);
	}

	const isActive = page && currentPath === page.path;

	const content = (
		<div
			class={`flex items-center gap-2 py-1 cursor-pointer select-none transition-colors duration-200 text-[0.8rem] group ${
				isActive ? "text-accent-primary" : "text-text-bright"
			} hover:text-accent-primary`}
			onClick={() => {
				if (item.items) {
					setExpanded(!expanded);
				}
			}}
		>
			{item.items && (
				<CaretDown
					size={14}
					class={`transition-transform duration-200 ${expanded ? "rotate-0" : "-rotate-90"}`}
				/>
			)}
			{Icon && <Icon size={16} />}
			{page ? (
				<NavLink
					href={page.path}
					currentPath={currentPath}
					className="text-[0.85rem] cursor-pointer no-underline transition-colors duration-200 text-inherit"
					onClick={(e: MouseEvent) => {
						e.stopPropagation();
						onClick();
					}}
				>
					<page.title />
				</NavLink>
			) : (
				<span class="text-inherit">{item.label}</span>
			)}
		</div>
	);

	return (
		<div class="mt-0.5">
			{content}
			{expanded && item.items && (
				<div class="pl-5 border-l border-glass-border ml-2.5">
					{item.items.map((subItem, i) => (
						<NavTree
							key={i}
							item={subItem}
							currentPath={currentPath}
							onClick={onClick}
						/>
					))}
				</div>
			)}
		</div>
	);
};

interface SidebarProps {
	isOpen: boolean;
	onClose: () => void;
	currentPath: string;
}

export function Sidebar({ isOpen, onClose, currentPath }: SidebarProps) {
	const currentTab = currentPath.startsWith("/api")
		? "api"
		: currentPath.startsWith("/mcp")
			? "mcp"
			: "guides";

	return (
		<>
			<nav
				class={`fixed md:sticky top-header-height left-0 h-[calc(100vh-var(--spacing-header-height))] p-2 border-r border-glass-border bg-sidebar-bg md:bg-sidebar-bg overflow-y-auto flex flex-col gap-1 z-[100] transition-transform duration-300 md:translate-x-0 ${
					isOpen ? "translate-x-0" : "-translate-x-full"
				} w-[280px] md:w-[18%] lg:w-[15%] md:min-w-[200px] md:max-w-[300px] shadow-[10px_0_30px_rgba(0,0,0,0.5)] md:shadow-none`}
				id="sidebar"
			>
				{/* MOBILE TABS */}
				<div class="md:hidden flex flex-col bg-black/40 data-[theme=light]:bg-black/5 border-b border-glass-border p-4 gap-2 -mx-2 mb-6">
					<NavLink
						href="/"
						currentPath={currentPath}
						className="flex items-center justify-center gap-2 p-3 rounded-md bg-white/10 data-[theme=light]:bg-black/5 text-text-bright border border-glass-border font-medium cursor-pointer transition-colors duration-200 hover:bg-white/15 data-[theme=light]:hover:bg-black/10 active:bg-accent-primary/20 active:text-accent-primary"
						onClick={() => onClose()}
					>
						<BookOpen size={16} /> Home
					</NavLink>
				</div>

				{NAVIGATION.map((navGroup) => (
					<div
						key={navGroup.tab}
						class={`flex-col gap-1 h-full ${currentTab === navGroup.tab ? "flex" : "hidden"}`}
					>
						{navGroup.groups.map((group, i) => (
							<div key={i} class="mb-2">
								<h4 class="text-[0.7rem] font-semibold uppercase tracking-wider text-text-bright mt-2 mb-1 ml-2">
									{group.title}
								</h4>
								{group.items.map((item, j) => (
									<NavTree
										key={j}
										item={item}
										currentPath={currentPath}
										onClick={onClose}
									/>
								))}
							</div>
						))}
					</div>
				))}
			</nav>
			<div
				id="mobile-backdrop"
				class={`md:hidden fixed inset-0 bg-black/60 backdrop-blur-sm z-[90] transition-opacity duration-300 ${
					isOpen
						? "opacity-100 pointer-events-auto"
						: "opacity-0 pointer-events-none"
				}`}
				onClick={onClose}
			></div>
		</>
	);
}
