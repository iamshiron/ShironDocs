import type { IconMap } from "./utils/icons";

export const CONFIG = {
	branding: {
		appTitle: "Project Title",
		appTitleShort: "Project",
		libraryName: "Project Library",
		tagline:
			"Project tagline goes here.",
		logoIcon: "Package" as keyof typeof IconMap,
		copyright: `© ${new Date().getFullYear()} Project. Licensed under MIT.`,
	},
	navigation: {
		externalLinks: {
			github: "https://github.com/username",
			repository: "https://github.com/username/repository",
			profile: "https://github.com/username",
		},
		footerLinks: [
			{ label: "Profile", href: "https://github.com/username" },
			{ label: "Repository", href: "#" },
			{ label: "License", href: "#" },
			{ label: "Contact", href: "#" },
		],
	},
};
