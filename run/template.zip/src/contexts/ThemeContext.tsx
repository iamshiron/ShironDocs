import { createContext, type ComponentChildren } from "preact";
import { useState, useEffect, useContext } from "preact/hooks";

interface ThemeContextType {
	theme: string;
	toggleTheme: () => void;
}

const ThemeContext = createContext<ThemeContextType>({
	theme: "dark",
	toggleTheme: () => {},
});

export function ThemeProvider({ children }: { children: ComponentChildren }) {
	const [theme, setTheme] = useState("dark");

	useEffect(() => {
		// Check system preference or localStorage if we were persisting
		// For now default to dark as per template
		const html = document.documentElement;
		if (theme === "light") {
			html.setAttribute("data-theme", "light");
		} else {
			html.removeAttribute("data-theme");
		}
	}, [theme]);

	const toggleTheme = () => {
		setTheme((prev) => (prev === "light" ? "dark" : "light"));
	};

	return (
		<ThemeContext.Provider value={{ theme, toggleTheme }}>
			{children}
		</ThemeContext.Provider>
	);
}

export function useTheme() {
	return useContext(ThemeContext);
}
