import { Header } from "../components/Header";
import { Sidebar } from "../components/Sidebar";
import { RightSidebar } from "../components/RightSidebar";
import { Footer } from "../components/Footer";
import { PageNavigation } from "../components/PageNavigation";
import { SearchModal } from "../components/SearchModal";
import { useState, useEffect } from "preact/hooks";
import type { ComponentChildren } from "preact";

interface LayoutProps {
	children: ComponentChildren;
	currentPath: string;
}

export function Layout({ children, currentPath }: LayoutProps) {
	const [sidebarOpen, setSidebarOpen] = useState(false);
	const [searchOpen, setSearchOpen] = useState(false);

	useEffect(() => {
		const handleKey = (e: KeyboardEvent) => {
			if ((e.ctrlKey || e.metaKey) && e.key === "/") {
				e.preventDefault();
				setSearchOpen(true);
			}
		};
		window.addEventListener("keydown", handleKey);
		return () => window.removeEventListener("keydown", handleKey);
	}, []);

	return (
		<>
			<SearchModal isOpen={searchOpen} onClose={() => setSearchOpen(false)} />

			<Header
				onMenuClick={() => setSidebarOpen(true)}
				onSearchClick={() => setSearchOpen(true)}
				currentPath={currentPath}
			/>

			<div class="flex w-full mt-header-height min-h-[calc(100vh-var(--spacing-header-height))]">
				<Sidebar
					isOpen={sidebarOpen}
					onClose={() => setSidebarOpen(false)}
					currentPath={currentPath}
				/>

				<main class="content flex-1 flex flex-col p-3 min-w-0">
					<div class="flex-1">
						{children}
						<PageNavigation currentPath={currentPath} />
					</div>
					<Footer />
				</main>

				<RightSidebar currentPath={currentPath} />
			</div>
		</>
	);
}
