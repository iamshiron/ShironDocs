import { hydrate, prerender as ssr } from "preact-iso";
import "./index.css";
import { App } from "./app";

if (typeof window !== "undefined") {
	hydrate(<App />, document.getElementById("app")!);
}

export async function prerender(data: any) {
	const { html, links } = await ssr(<App {...data} />);
	return {
		html,
		links,
	};
}
