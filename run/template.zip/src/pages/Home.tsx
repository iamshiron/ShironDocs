import { PageWrapper } from "../components/PageWrapper";

export const label = "Home";
export const title = () => <span>{label}</span>;

export const Page = () => (
	<PageWrapper>
		<h1>Welcome</h1>
		<p>This is the default home page. Generated content will appear in the navigation.</p>
	</PageWrapper>
);
