This directory is for API documentation pages.
Generated files should export:
- label (string)
- title (component)
- Page (component)
