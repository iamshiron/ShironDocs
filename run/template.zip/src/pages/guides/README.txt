This directory is for user guides and manual pages.
Generated files should export:
- label (string)
- title (component)
- Page (component)
