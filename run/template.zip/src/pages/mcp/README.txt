This directory is for MCP (Model Context Protocol) integration documentation.
Generated files should export:
- label (string)
- title (component)
- Page (component)
