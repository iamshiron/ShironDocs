import type { ComponentType } from "preact";
import type { IconName } from "./icons";

export interface Page {
	id: string;
	label: string;
	title: ComponentType<any>;
	Content: ComponentType<any>;
	path: string;
	tab: string;
}

export interface NavItem {
	id?: string;
	label?: string;
	icon?: IconName;
	items?: NavItem[];
}

export interface NavGroup {
	tab: string;
	groups: {
		title: string;
		items: NavItem[];
	}[];
}

import * as Home from "../pages/Home";

export const PAGES: Page[] = [
	{
		id: "home",
		label: Home.label,
		title: Home.title,
		Content: Home.Page,
		path: "/",
		tab: "home",
	},
];

export const NAVIGATION: NavGroup[] = [
	{
		tab: "home",
		groups: [
			{
				title: "General",
				items: [{ id: "home" }],
			},
		],
	},
];